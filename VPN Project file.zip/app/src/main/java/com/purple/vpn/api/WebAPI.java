package com.purple.vpn.api;

public class WebAPI {
    public static String ADMIN_PANEL_API = "https://vpn.truetest.xyz/";    // Put your Base_URL
    public static String FREE_SERVERS = "";
    public static String PREMIUM_SERVERS = "";
    public static String ADMOB_BANNER = "";
    public static String ADMOB_INTERSTITIAL = "";
    public static String ADMOB_ID = "";
    public static String ADMOB_NATIVE = "";
    public static String ADMOB_REWARD_ID = "";
    public static String ADS_TYPE = "";
    public static String ADS_TYPE_ADMOB = "ADMOB";
    public static String ADS_TYPE_FACEBOOK_ADS = "FACEBOOK_ADS";
    public static String TYPE_APPODEAL = "APPODEAL";
    public static String TYPE_UNITY = "UNV";
    public static String TYPE_STARTAPP = "STARTAPP";

    public static com.appodeal.ads.NativeAd nativeAd = null; // Under Development  10/2
    public static boolean rewardedVideoLoaded = false;
    public static boolean interstitialLoaded = false;
    public static boolean bannerLoaded = false;
    public static String TYPE_MP = "MPV";
    public static String TYPE_APV = "APV";


}
