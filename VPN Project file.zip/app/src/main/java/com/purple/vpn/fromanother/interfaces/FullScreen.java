package com.purple.vpn.fromanother.interfaces;

public interface FullScreen {

    void fullscreen(boolean isFull);

}
