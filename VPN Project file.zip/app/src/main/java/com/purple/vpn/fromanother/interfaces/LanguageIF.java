package com.purple.vpn.fromanother.interfaces;

public interface LanguageIF {

    void selectLanguage(String id, String type, int position, boolean isValue);

}
