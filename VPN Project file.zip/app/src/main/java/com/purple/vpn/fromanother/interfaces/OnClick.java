package com.purple.vpn.fromanother.interfaces;

public interface OnClick {

    void position(int position, String title, String type, String statusType, String id, String tag);

}
