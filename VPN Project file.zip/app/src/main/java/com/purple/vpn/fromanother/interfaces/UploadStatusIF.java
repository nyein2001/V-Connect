package com.purple.vpn.fromanother.interfaces;

public interface UploadStatusIF {

    void UploadType(String type);

}
