package com.purple.vpn.fromanother.interfaces;

public interface VideoAd {

    void videoAdClick(String type);

}
