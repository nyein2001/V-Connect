package com.purple.vpn.interfaces;

import com.purple.vpn.model.Server;

public interface ChangeServer {
    void newServer(Server server);
}
