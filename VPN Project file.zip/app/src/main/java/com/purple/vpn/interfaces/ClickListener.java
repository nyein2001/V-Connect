package com.purple.vpn.interfaces;

import com.purple.vpn.model.Language;

public interface ClickListener<Language> {
    public void onClick(Language data);
}
