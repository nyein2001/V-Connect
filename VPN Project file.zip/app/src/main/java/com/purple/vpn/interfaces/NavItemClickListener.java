package com.purple.vpn.interfaces;

public interface NavItemClickListener {
    void clickedItem(int index);
}
