package com.purple.vpn.model;

public class Words {
    public String name;
    public String value;
    public Words(String name, String value) {
        this.name = name;
        this.value = value;
    }
}
