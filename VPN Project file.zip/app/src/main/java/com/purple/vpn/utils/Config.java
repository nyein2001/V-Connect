package com.purple.vpn.utils;

public class Config {

    public static final String all_month_id = "vpn1";
    public static final String all_threemonths_id = "vpn2";
    public static final String all_sixmonths_id = "vpn3";
    public static final String all_yearly_id = "vpn4";

    public static final String monthly_stripe_id = "price_1OIF2KSCsgjTbctB7m6arcHu";
    public static final String months_3_stripe_id = "price_1OIF38SCsgjTbctBFmdh8VWd";
    public static final String months_6_stripe_id = "price_1OIF3aSCsgjTbctB41hOJSH1";
    public static final String yearly_stripe_id = "price_1OIF4BSCsgjTbctBEKOVAVkC";

    public static boolean vip_subscription = false;
    public static boolean all_subscription = false;

    public static boolean no_ads = false;

    public static boolean is_premium = false;

    public static boolean premium_servers_access = false;

    public static String ONESIGNAL_APP_ID = "490952c1-2edc-4c01-a905-ea137000b3b1";

    public static String perks = "";

    public static String expiration = "";

    public static String stripe_json = "";

    public static String stripe_renew_date = "";

    public static String stripe_status = "";
}


