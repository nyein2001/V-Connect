package com.purple.vpn.utils;


import com.purple.vpn.model.Language;
import com.purple.vpn.model.Words;

import java.util.ArrayList;
import java.util.List;

public class Global {

    public static List<Language> LANGUAGE_LIST = null;
    public static List<Words> WORD_LIST = new ArrayList<>();
}
