import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class ShimmerObject extends StatelessWidget {
  final double? width, height;
  final BorderRadius? radius;
  final EdgeInsets? margin, padding;

  const ShimmerObject({super.key, this.width, this.height, this.radius, this.margin, this.padding});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width ?? double.infinity,
      height: height ?? double.infinity,
      decoration: BoxDecoration(borderRadius: radius ?? BorderRadius.circular(5), color: Colors.grey.shade100),
      margin: margin ?? const EdgeInsets.only(),
      padding: padding ?? const EdgeInsets.only(),
    );
  }
}

class ShimmeringObject extends StatelessWidget {
  final double? width, height;
  final BorderRadius? radius;
  final EdgeInsets? margin, padding;

  const ShimmeringObject({super.key, this.width, this.height, this.radius, this.margin, this.padding});
  @override
  Widget build(BuildContext context) {
    return ShimmerContainer(
      child: ShimmerObject(
        width: width ?? double.infinity,
        height: height ?? double.infinity,
        margin: margin ?? const EdgeInsets.only(),
        padding: padding ?? const EdgeInsets.only(),
        radius: radius ?? BorderRadius.circular(10),
      ),
    );
  }
}

class ShimmerContainer extends StatelessWidget {
  final Widget? child;
  const ShimmerContainer({super.key, this.child});
  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(baseColor: Colors.grey.shade200, highlightColor: Colors.grey.shade100, child: child!);
  }
}
